// Rendering logic
const CELL_SIZE = 30;
const CANVAS_WIDTH = CELL_SIZE * 20;
const CANVAS_HEIGHT = CELL_SIZE * 20;

export function drawMaze(ctx, maze, player, fogOfWar, visibleCells) {
    ctx.clearRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    ctx.strokeStyle = '#8a0303';
    ctx.lineWidth = 2;
    for (let y = 0; y < 20; y++) {
        for (let x = 0; x < 20; x++) {
            if (fogOfWar && !visibleCells[`${x},${y}`]) continue;
            const distance = Math.sqrt(Math.pow(x - player.x, 2) + Math.pow(y - player.y, 2));
            const alpha = fogOfWar ? Math.max(0, 1 - distance / 5) : 1;
            const cellX = x * CELL_SIZE;
            const cellY = y * CELL_SIZE;
            ctx.fillStyle = `rgba(20, 20, 20, ${alpha})`;
            ctx.fillRect(cellX, cellY, CELL_SIZE, CELL_SIZE);
            const cell = maze[y][x];
            if (cell.walls.top) { ctx.beginPath(); ctx.moveTo(cellX, cellY); ctx.lineTo(cellX + CELL_SIZE, cellY); ctx.stroke(); }
            if (cell.walls.right) { ctx.beginPath(); ctx.moveTo(cellX + CELL_SIZE, cellY); ctx.lineTo(cellX + CELL_SIZE, cellY + CELL_SIZE); ctx.stroke(); }
            if (cell.walls.bottom) { ctx.beginPath(); ctx.moveTo(cellX, cellY + CELL_SIZE); ctx.lineTo(cellX + CELL_SIZE, cellY + CELL_SIZE); ctx.stroke(); }
            if (cell.walls.left) { ctx.beginPath(); ctx.moveTo(cellX, cellY); ctx.lineTo(cellX, cellY + CELL_SIZE); ctx.stroke(); }
        }
    }
}

// ... existing code for drawPlayer, drawWeirdThings ...
export { drawPlayer, drawWeirdThings }; 