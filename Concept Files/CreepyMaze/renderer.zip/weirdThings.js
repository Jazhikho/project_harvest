// Weird things management
export class WeirdThings {
    constructor() {
        this.items = [];
    }

    placeWeirdThings(maze, player) {
        this.items = [];
        const numWeirdThings = 5 + Math.floor(Math.random() * 5);
        for (let i = 0; i < numWeirdThings; i++) {
            let x, y;
            do {
                x = 1 + Math.floor(Math.random() * 18);
                y = 1 + Math.floor(Math.random() * 18);
            } while ((x === player.x && y === player.y) || this.weirdThingAt(x, y));
            this.items.push({ x, y, type: Math.floor(Math.random() * 5), found: false });
        }
    }

    weirdThingAt(x, y) {
        return this.items.some(thing => thing.x === x && thing.y === y);
    }

    getWeirdThingAt(x, y) {
        return this.items.find(thing => thing.x === x && thing.y === y);
    }

    // ... existing code for getWeirdMessage, applyWeirdEffect ...
}

export { getWeirdMessage, applyWeirdEffect }; 