// Maze generation and modification logic
const GRID_WIDTH = 20;
const GRID_HEIGHT = 20;

export function generateMaze(maze) {
    for (let y = 0; y < GRID_HEIGHT; y++) {
        maze[y] = [];
        for (let x = 0; x < GRID_WIDTH; x++) {
            maze[y][x] = { walls: { top: true, right: true, bottom: true, left: true }, visited: false };
        }
    }
    let startX = 1 + Math.floor(Math.random() * (GRID_WIDTH - 2));
    let startY = 1 + Math.floor(Math.random() * (GRID_HEIGHT - 2));
    maze[startY][startX].visited = true;
    let stack = [{ x: startX, y: startY }];
    while (stack.length > 0) {
        let current = stack[stack.length - 1];
        let neighbors = getUnvisitedNeighbors(current.x, current.y, maze);
        if (neighbors.length > 0) {
            let next = neighbors[Math.floor(Math.random() * neighbors.length)];
            removeWall(current, next, maze);
            maze[next.y][next.x].visited = true;
            stack.push(next);
        } else {
            stack.pop();
        }
    }
    for (let y = 0; y < GRID_HEIGHT; y++) {
        for (let x = 0; x < GRID_WIDTH; x++) {
            maze[y][x].visited = false;
        }
    }
    addCreepyPatterns(maze);
    return maze;
}

// ... existing code for getUnvisitedNeighbors, removeWall, addCreepyPatterns, changeMazePart ...
export { getUnvisitedNeighbors, removeWall, addCreepyPatterns, changeMazePart }; 