// Main game logic
import { generateMaze, changeMazePart } from './mazeGenerator.js';
import { Player } from './player.js';
import { drawMaze, drawPlayer, drawWeirdThings } from './renderer.js';
import { WeirdThings, getWeirdMessage, applyWeirdEffect } from './weirdThings.js';
import { updateVisibility } from './utils.js';

export class Game {
    constructor() {
        this.maze = [];
        this.player = new Player();
        this.weirdThings = new WeirdThings();
        this.weirdFindings = 0;
        this.gameOver = false;
        this.visibleCells = {};
        this.lastMazeChange = 0;
        this.mazeChangeInterval = 30000;
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.messageOverlay = document.getElementById('message-overlay');
    }

    init() {
        generateMaze(this.maze);
        this.weirdThings.placeWeirdThings(this.maze, this.player);
        document.addEventListener('keydown', (e) => this.handleKeyDown(e));
        document.addEventListener('mousemove', handleMouseMove);
        this.gameLoop();
    }

    handleKeyDown(event) {
        if (this.gameOver || parseFloat(this.messageOverlay.style.opacity || 0) > 0) return;
        if (this.player.move(event.key, this.maze)) {
            updateVisibility(this.player, this.maze, this.visibleCells);
            this.checkWeirdThings();
            // ... existing code for checkExitTrigger, checkMazeChange, progressNarrative ...
        }
    }

    gameLoop() {
        drawMaze(this.ctx, this.maze, this.player, true, this.visibleCells);
        drawPlayer(this.ctx, this.player);
        drawWeirdThings(this.ctx, this.weirdThings.items);
        requestAnimationFrame(() => this.gameLoop());
    }

    // ... existing code for checkWeirdThings, triggerJumpscare, showMessage, etc. ...
} 